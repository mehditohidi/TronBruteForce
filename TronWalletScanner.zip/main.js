const TronWeb = require('tronweb');
const fs = require('fs');
const tronWeb = new TronWeb({
  fullHost: 'https://api.trongrid.io', // Replace with the appropriate full node URL
});

function generateRandomPrivateKey() {
  // Generate a random private key
  const crypto = require('crypto');
  const privateKey = crypto.randomBytes(32).toString('hex');
  return privateKey;
}

function privateKeyToAddress(privateKey) {
  // Derive the TRON address from the private key
  return tronWeb.address.fromPrivateKey(privateKey);
}

async function checkTronTransactions(address) {
    try {
      // Get the latest block number
      const latestBlock = await tronWeb.trx.getCurrentBlock();
  
      // Specify the number of blocks to check (adjust as needed)
      const blockCount = 100;
  
      // Calculate the block number to start checking from
      const startBlock = latestBlock.block_header.raw_data.number - blockCount;
  
      // Retrieve transactions for the given address within the specified range
      const transactions = await tronWeb.trx.getTransactionsRelated(address, 'all', blockCount, startBlock);
  
      // Check if there are any transactions
      const hasTransactions = transactions.length > 0;
  
      return hasTransactions;
    } catch (error) {
      console.error('Error checking transactions:', error);
      return false; // Return false in case of an error
    }
  }

function saveToFile(filePath, content) {
  fs.writeFileSync(filePath, content + '\n', { flag: 'a' });
}

async function generateAndCheckTronWallets() {
  console.log('Starting TRON wallet generation and checking...');

  for (let i = 0; i < 10000000; i++) { // Generate 10,000,000 wallets for example
    const privateKey = generateRandomPrivateKey();
    const address = privateKeyToAddress(privateKey);
    const hasTransactions = await checkTronTransactions(address);

    if (hasTransactions) {
      console.log(`Checking wallet of ${address}: Wallet has transactions.`);
      saveToFile('wallets_with_transactions.txt', `${address}:${privateKey}`);
    } else {
      console.log(`Checking wallet of ${address}: Wallet is empty.`);
      saveToFile('wallets_without_transactions.txt', `${address}:${privateKey}`);
    }
  }

  console.log('TRON wallet generation and checking completed.');
}

// Run the TRON wallet generation and checking process
generateAndCheckTronWallets();
